TYPE
	GA_State : 
		(
		GA_FAULT := 0,
		WAIT := 1,
		SET_POSITION := 2,
		SET_VELOCITY := 3
	    );
END_TYPE