TYPE
	GA_State : 
		(
		CheckCommand,
		WaitTargetVelocity,
		WaitTargetPosition,
		FaultState
	);
END_TYPE