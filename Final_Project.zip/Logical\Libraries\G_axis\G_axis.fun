
FUNCTION_BLOCK G_axis
	VAR_INPUT
		Execute : WORD := 95;
		CurrentPosition : REAL;
		CurrentVelocity : REAL;
		TargetPose : REAL;
		DeviceTimer : INT;
		TGT_SENSOR : BOOL;
		Reset : BOOL;
	END_VAR
	VAR_OUTPUT
		TargetVelocity : REAL;
		TargetPosition : REAL;
		IsPosTarget : BOOL;
		IsVelTarget : BOOL;
		DeviceFault : BOOL;
	END_VAR
	VAR
		STATES : GA_State := WAIT;
		Timer : INT;
	END_VAR
END_FUNCTION_BLOCK
