
TYPE
	STATE_TYPE_MACHINE : 
		(
		FAULT_STATE,
		OFF_STATE, (*the system is off. this state can be reached by every other state under the correct conditions*)
		WAIT_POWER, (*the system is not off but it needs to be powered*)
		RUNNING_STATE, (*the system is in the running state and waits for conditions to either go in a triggered state or be turned off*)
		TRIGGERED_STATE, (*the system has been triggered and is getting ready for the cutting action*)
		CUTTING_STATE, (*the system performs the cut and gets ready to go back to running state*)
		STOPPED (*The sytem is in the off state*)
	);
END_TYPE