
TYPE
	STATE_TYPE : 
		(
		FAULT_STATE_CUTTER,
		OFF_STATE_CUTTER, (*Off state*)
		INIT_AXIS, (*Initialization of the general axis for the cutter*)
		AXIS_ENABLED, (*State in which the axis is enabled and ready to go into the cutting process*)
		MOVING_DOWN, (*The cutter lowers getting close enough to perform the cut*)
		CUTTER_DOWN, (*The cutting action happens and the corresponding movement and position variables are set*)
		MOVING_UP (*The cutter goes up away from the position used to perform the cut*)
	);
END_TYPE
