
TYPE
	STATE_TYPE : 
		(
		FAULT_STATE_CONVEYOR,
		OFF_STATE_CONVEYOR, (*Off state*)
		INIT_AXIS, (*Initialization of the general axis*)
		AXIS_ENABLED, (*Enabling of the axis relative to the conveyor*)
		CONV_STARTING, (*Initialization of the conveyor*)
		CONV_MOVING, (*Initialization of the movement of the conveyor and relative variables*)
		CONV_STOPED (*Stopping of the movement of the conveyor and setting of the relative variables*)
	);
END_TYPE
