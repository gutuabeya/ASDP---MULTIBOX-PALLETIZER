
{REDUND_ERROR} FUNCTION_BLOCK GENERIC_AXIS (*TODO: Add your comment here*) (*$GROUP=User,$CAT=User,$GROUPICON=User.png,$CATICON=User.png*)
	VAR_INPUT
		velocity : {REDUND_UNREPLICABLE} REAL;
		acceleration : {REDUND_UNREPLICABLE} REAL;
		deceleration : {REDUND_UNREPLICABLE} REAL;
		direction : {REDUND_UNREPLICABLE} USINT;
		position : {REDUND_UNREPLICABLE} REAL;
		distance : REAL;
		axis_command : {REDUND_UNREPLICABLE} STRING[80];
		axis_address : UDINT;
	END_VAR
	VAR_OUTPUT
		actual_position : REAL;
		axis_error : {REDUND_UNREPLICABLE} BOOL;
		error_id : {REDUND_UNREPLICABLE} WORD;
		axis_state : {REDUND_UNREPLICABLE} STATE_TYPE_GA;
		command_executed : BOOL;
	END_VAR
	VAR_IN_OUT
		axis_enable : BOOL;
	END_VAR
	VAR
		power_GA : MC_Power;
		home_GA : MC_Home;
		move_velocity_GA : MC_MoveVelocity;
		move_additive_GA : MC_MoveAdditive;
		move_position_GA : MC_MoveAbsolute;
		status_GA : MC_ReadStatus;
		position_GA : MC_ReadActualPosition;
		reset_GA : MC_Reset;
		read_axis_error_GA : MC_ReadAxisError;
		old_command : STRING[80];
		mc_stop_GA : MC_Stop;
		old_velocity : REAL;
	END_VAR
END_FUNCTION_BLOCK
